# MAX519mp3/mp4

Aplicación Flask optimizada para pantallas móviles. Busca videos por título o acepta enlaces directos de YouTube, limpia parámetros de seguimiento, ofrece selección MP3/MP4 y muestra el progreso de procesamiento.

## Requisitos
- Python 3.10 o superior
- FFmpeg instalado y disponible en `PATH` (necesario para convertir a MP3 y combinar pistas de video)
- Conexión a internet

## Ejecutar localmente
1. Instalar Python y FFmpeg.
2. En la carpeta del proyecto, ejecutar:
   ```bash
   python -m venv .venv
   ```
   Activar el entorno virtual y ejecutar:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
3. Abrir `http://127.0.0.1:5000`.

## Publicar
Subí los archivos a un servicio compatible con Python/Flask. Configurá el comando de inicio como:
`gunicorn --workers 2 --threads 4 --timeout 3600 --bind 0.0.0.0:$PORT app:app`

El servidor necesita FFmpeg y espacio temporal suficiente. Para una app pública real se recomienda usar una cola de trabajos persistente, almacenamiento temporal con limpieza automática, límites de concurrencia, límites de tamaño y protección contra abuso. El ejemplo guarda trabajos en memoria y los archivos en disco local; no está diseñado para múltiples instancias ni para uso público de alto volumen.

## Cambiar el logo
Reemplazá `static/logo.svg`. Para un ícono APK, exportá el diseño a PNG y añadilo al proyecto Android/WebView o al generador de APK que uses.

## Notas importantes
- La app no puede elegir silenciosamente la carpeta Descargas de Android desde una página web. La descarga se entrega con `Content-Disposition: attachment`; el navegador o la APK decide dónde guardarla.
- El progreso de esta interfaz corresponde al procesamiento en el servidor. El avance de la descarga al teléfono depende del navegador/Android y se muestra en su administrador de descargas cuando es compatible.
- Los videos están limitados a 5 horas. El límite real también depende del alojamiento y su espacio, memoria, timeout y ancho de banda.
- Usá la herramienta solo con material que tengas derecho a descargar y respetá las condiciones de la plataforma.
