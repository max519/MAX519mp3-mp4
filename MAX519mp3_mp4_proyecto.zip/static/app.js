const $ = (id) => document.getElementById(id);
let selectedMode = "mp3";
let selectedUrl = "";
let currentJob = null;
let pollTimer = null;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 3200);
}
async function postJSON(url, body) {
  const response = await fetch(url, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Ocurrió un error. Intentá de nuevo.");
  return data;
}
function durationLabel(seconds) {
  if (!seconds) return "Duración no disponible";
  const h = Math.floor(seconds/3600), m = Math.floor((seconds%3600)/60);
  return h ? `${h} h ${m} min` : `${m} min`;
}
function renderResults(results) {
  const root = $("results");
  root.innerHTML = "";
  $("resultsSection").classList.remove("hidden");
  $("resultCount").textContent = `${results.length} resultado${results.length===1?"":"s"}`;
  if (!results.length) { root.innerHTML = '<p class="muted">No se encontraron resultados.</p>'; return; }
  results.forEach((item) => {
    const card = document.createElement("article"); card.className = "result-card";
    const icon = document.createElement("div"); icon.className = "result-play"; icon.textContent = "▶";
    const copy = document.createElement("div"); copy.className = "result-copy";
    const title = document.createElement("strong"); title.textContent = item.title || "Video de YouTube";
    const meta = document.createElement("small"); meta.textContent = [item.channel, durationLabel(item.duration)].filter(Boolean).join(" · ");
    copy.append(title, meta);
    const choose = document.createElement("button"); choose.className = "choose-button"; choose.textContent = "Elegir";
    choose.addEventListener("click", () => {
      selectedUrl = item.url;
      $("query").value = item.url;
      $("downloadButton").disabled = false;
      $("downloadButton").innerHTML = 'Descargar en ' + selectedMode.toUpperCase() + ' <span>→</span>';
      document.querySelectorAll(".result-card").forEach(c=>c.classList.remove("chosen"));
      card.classList.add("chosen");
      toast("Video seleccionado. Elegí MP3 o MP4 y descargá.");
      $("downloadSection").classList.remove("hidden");
      $("fileTitle").textContent = item.title || "Video seleccionado";
      $("downloadMessage").textContent = "Listo para iniciar la descarga.";
    });
    card.append(icon,copy,choose); root.append(card);
  });
}
$("searchForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query = $("query").value.trim();
  if (!query) return;
  const button = e.submitter; button.disabled = true; button.textContent = "Buscando…";
  try {
    const data = await postJSON("/api/search", {query});
    renderResults(data.results || []);
    if (data.results && data.results.length === 1 && data.results[0].url) {
      selectedUrl = data.results[0].url;
      $("downloadButton").disabled = false;
      $("downloadButton").innerHTML = `Descargar en ${selectedMode.toUpperCase()} <span>→</span>`;
    }
  } catch (err) { toast(err.message); }
  finally { button.disabled = false; button.textContent = "Buscar"; }
});
document.querySelectorAll(".format-option").forEach(button => button.addEventListener("click", () => {
  selectedMode = button.dataset.mode;
  document.querySelectorAll(".format-option").forEach(b=>b.classList.toggle("selected",b===button));
  $("downloadButton").innerHTML = `Descargar en ${selectedMode.toUpperCase()} <span>→</span>`;
}));
$("downloadButton").addEventListener("click", async () => {
  const url = selectedUrl || $("query").value.trim();
  if (!url) { toast("Primero pegá un enlace o buscá un video."); return; }
  $("downloadButton").disabled = true;
  $("downloadSection").classList.remove("hidden");
  $("fileIcon").textContent = selectedMode === "mp3" ? "♫" : "▶";
  $("fileStatus").textContent = "Conectando con YouTube…";
  $("saveButton").classList.add("hidden");
  $("progressBar").style.width = "0%";
  $("percent").textContent = "0%";
  $("downloadMessage").textContent = "Iniciando…";
  try {
    const data = await postJSON("/api/download", {url,mode:selectedMode});
    currentJob = data.job_id;
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(() => pollProgress(currentJob), 1200);
    pollProgress(currentJob);
  } catch(err) {
    toast(err.message); $("downloadButton").disabled = false;
  }
});
async function pollProgress(jobId) {
  try {
    const response = await fetch(`/api/progress/${jobId}`, {cache:"no-store"});
    const data = await response.json();
    $("statusPill").textContent = data.state === "ready" ? "Listo" : data.state === "error" ? "Error" : "En proceso";
    $("percent").textContent = `${data.percent || 0}%`;
    $("progressBar").style.width = `${Math.min(100, data.percent || 0)}%`;
    $("speed").textContent = `Velocidad: ${data.speed || "—"}`;
    $("eta").textContent = `Restante: ${data.eta || "—"}`;
    $("downloadMessage").textContent = data.message || "Procesando…";
    if (data.state === "downloading") $("fileStatus").textContent = "Descargando…";
    else if (data.state === "processing") $("fileStatus").textContent = "Preparando archivo final…";
    else if (data.state === "ready") {
      $("fileStatus").textContent = "Archivo listo para guardar";
      $("fileTitle").textContent = data.title || "Archivo multimedia";
      $("saveButton").href = data.download_url;
      $("saveButton").classList.remove("hidden");
      $("saveButton").textContent = "Guardar archivo en Descargas ↓";
      $("downloadButton").disabled = false;
      clearInterval(pollTimer); pollTimer = null;
      toast("¡Archivo listo! Tocá Guardar archivo.");
    } else if (data.state === "error") {
      clearInterval(pollTimer); pollTimer = null;
      $("downloadButton").disabled = false; toast(data.message || "Falló la descarga.");
    }
  } catch(e) { /* transient network issue; next poll retries */ }
}
$("settingsButton").addEventListener("click", () => $("settingsPanel").classList.toggle("hidden"));
$("closeSettings").addEventListener("click", () => $("settingsPanel").classList.add("hidden"));
